# WhatsChat - Communication + Productivity

A WhatsApp-like chat application built with **Java 25, Spring Boot 4, Spring MVC, Spring Security,
Spring Data JPA / Hibernate, MySQL, Thymeleaf and Bootstrap**.

**The idea:** a messaging app is for communication. WhatsChat connects communication with productivity:
an important message can be turned into a **bookmark, reminder or task**.
Example: a team member sends *"Complete the database module by Friday"* -> click the task icon ->
Task: *Database module*, Assignee: *Yagesh*, Deadline: *Friday*, Status: *Pending*.

## Run it

1. Install MySQL and make sure it is running on `localhost:3306`.
2. Open `src/main/resources/application.properties` and set your MySQL user/password
   (or set the environment variables `DB_USERNAME` and `DB_PASSWORD`).
   The database `whatsapp_db` and all tables are created automatically on first start.
3. Run:
   ```
   ./mvnw spring-boot:run        (Windows: mvnw.cmd spring-boot:run)
   ```
4. Open http://localhost:8080 , register two accounts (use a private window for the second one) and chat.

Run the unit tests (no database needed): `./mvnw test`

## Requirement -> where it is implemented

| Requirement | Code |
|---|---|
| Registration (username, email, password -> `users`) | `AuthController`, `RegisterForm`, `UserService.register`, `register.html` |
| Login with email **or** username | `AppUserDetailsService`, `SecurityConfig`, `login.html` |
| Dashboard (current user, other users, unread badges, logout) | `DashboardController`, `dashboard.html`, navbar in `fragments.html` |
| One-to-one chat (sender, receiver, time) | `ChatController`, `MessageService.send`, `chat.html`, `chat.js` |
| `messages` table (id, sender_id, receiver_id, message, sent_at, is_read) | `Message` entity |
| Unread messages -> read when the chat is opened | `MessageRepository.markConversationRead`, `MessageService.openConversation` |
| Chat history | `MessageRepository.findConversation` |
| Logout | `SecurityConfig` (`POST /logout`) |
| Bookmark a message | `Bookmark`, `BookmarkService`, `BookmarkController` |
| Message -> Reminder | `Reminder`, `ReminderService`, `ReminderController` |
| Message -> Task (assignee, deadline, Pending / In Progress / Completed) | `Task`, `TaskStatus`, `TaskService`, `TaskController` |
| Chat insights | `InsightService`, `Insights`, `insights.html` |

## Request flow

```
Browser -> Controller -> Service -> Repository -> JPA/Hibernate -> MySQL
```

## Database tables (created by Hibernate)

`users`, `messages`, `bookmarks`, `reminders`, `tasks`

## Design decisions worth explaining in an interview

* **Passwords are BCrypt-hashed** (`BCryptPasswordEncoder`), never stored in plain text.
* **CSRF protection is on**: every POST form carries a token (`th:action` adds it automatically).
* **Authorization on every message action**: `MessageService.getForParticipant` returns 404 unless you are the sender
  or receiver, so nobody can bookmark/convert someone else's message by guessing ids.
  Update/delete queries also include the owner's id in the `WHERE` clause.
* **Validation in layers**: Bean Validation on the form -> business rules in services -> unique constraints in the database.
* **Live chat by polling**: `chat.js` fetches the message-list fragment every 3 seconds. It is simple and reliable.
  The WebSocket starter is already in the `pom.xml` - upgrading to STOMP is the natural next step.
* **Unread counting** uses one `GROUP BY` query for the whole dashboard instead of one query per user.
* **Chat insights** are computed in a pure method (`InsightService.compute`) so it can be unit-tested without a database.

## Known limitations / next steps

* Reminders appear on the Reminders page and as a "due now" count on the dashboard; there is no push notification yet.
* Date/time inputs use the server's time zone (fine when browser and server are on the same machine).
* Next features: group chats, WebSocket/STOMP real-time delivery, message search, profile picture, Docker + deployment.
