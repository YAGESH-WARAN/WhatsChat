// Live chat without WebSockets: poll the server every 3 seconds for the message list.
(function () {
    const scroller = document.getElementById('chatScroll');
    const body = document.getElementById('chatBody');
    const form = document.getElementById('sendForm');
    const input = document.getElementById('text');
    const pollUrl = body.dataset.pollUrl;
    let lastKey = null;
    let busy = false;

    const scrollDown = () => { scroller.scrollTop = scroller.scrollHeight; };
    scrollDown();

    // Spring Security puts a different (masked) _csrf value in every rendered form,
    // so remove those inputs before comparing "did anything really change?"
    const keyOf = (html) => html.replace(/<input[^>]*name="_csrf"[^>]*>/g, '');

    async function refresh(forceScroll) {
        if (busy) return;
        busy = true;
        try {
            const res = await fetch(pollUrl, { cache: 'no-store' });
            if (!res.ok) return;
            const html = await res.text();
            const key = keyOf(html);
            if (key !== lastKey) {
                lastKey = key;
                const tmp = document.createElement('div');
                tmp.innerHTML = html;
                const fresh = tmp.firstElementChild;
                if (fresh) {
                    const nearBottom = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 80;
                    body.innerHTML = fresh.innerHTML;
                    if (nearBottom || forceScroll) scrollDown();
                }
            } else if (forceScroll) {
                scrollDown();
            }
        } catch (e) {
            /* network hiccup - try again on the next tick */
        } finally {
            busy = false;
        }
    }

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const text = input.value.trim();
        if (!text) return;
        const data = new URLSearchParams(new FormData(form)); // includes the CSRF token
        input.value = '';
        try {
            // redirect:'manual' - the server answers with a redirect; we do not need to follow it
            await fetch(form.action, { method: 'POST', body: data, redirect: 'manual' });
        } catch (e) {
            input.value = text; // sending failed - give the text back
            return;
        }
        refresh(true);
    });

    setInterval(() => { if (!document.hidden) refresh(false); }, 3000);
    refresh(false);
    input.focus();

    // Reminder / task modals: point the form at the clicked message.
    function wireModal(id, fillTitle) {
        const modal = document.getElementById(id);
        modal.addEventListener('show.bs.modal', (event) => {
            const btn = event.relatedTarget;
            const f = modal.querySelector('form');
            f.action = f.dataset.template.replace('MSGID', btn.dataset.messageId);
            modal.querySelector('.msg-preview').textContent = btn.dataset.messageText;
            if (fillTitle) {
                modal.querySelector('#taskTitle').value = btn.dataset.messageText.substring(0, 200);
            }
        });
    }
    wireModal('reminderModal', false);
    wireModal('taskModal', true);
})();
