package com.example.whatsapp.controller;

import com.example.whatsapp.dto.RegisterForm;
import com.example.whatsapp.service.UserService;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/dashboard";
    }

    @GetMapping("/login")
    public String login() {
        return "login"; // POST /login is handled by Spring Security
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("form", new RegisterForm());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("form") RegisterForm form, BindingResult result) {
        // Field-level rules (@NotBlank, @Email, @Size...) have already run. Now the cross-field / database rules:
        if (!result.hasFieldErrors("confirmPassword") && !result.hasFieldErrors("password")
                && !form.getPassword().equals(form.getConfirmPassword())) {
            result.rejectValue("confirmPassword", "mismatch", "Passwords do not match");
        }
        if (!result.hasFieldErrors("username") && userService.isUsernameTaken(form.getUsername())) {
            result.rejectValue("username", "taken", "This username is already taken");
        }
        if (!result.hasFieldErrors("email") && userService.isEmailTaken(form.getEmail())) {
            result.rejectValue("email", "taken", "An account with this email already exists");
        }
        if (result.hasErrors()) {
            return "register";
        }
        try {
            userService.register(form);
        } catch (DataIntegrityViolationException e) {
            // two people registered the same username at the same moment - the DB unique constraint caught it
            result.rejectValue("username", "taken", "This username or email was just taken");
            return "register";
        }
        return "redirect:/login?registered";
    }
}
