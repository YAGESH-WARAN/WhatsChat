package com.example.whatsapp.service;

import com.example.whatsapp.model.Bookmark;
import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.BookmarkRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class BookmarkService {

    private final BookmarkRepository bookmarkRepository;

    public BookmarkService(BookmarkRepository bookmarkRepository) {
        this.bookmarkRepository = bookmarkRepository;
    }

    /** Star / un-star. Returns true if the message is bookmarked after the call. The caller has checked access. */
    @Transactional
    public boolean toggle(User me, Message message) {
        Optional<Bookmark> existing = bookmarkRepository.findByUserIdAndMessageId(me.getId(), message.getId());
        if (existing.isPresent()) {
            bookmarkRepository.delete(existing.get());
            return false;
        }
        bookmarkRepository.save(new Bookmark(me, message));
        return true;
    }

    @Transactional(readOnly = true)
    public List<Bookmark> list(Long myId) {
        return bookmarkRepository.findAllForUser(myId);
    }

    @Transactional(readOnly = true)
    public Set<Long> bookmarkedMessageIds(Long myId) {
        return new HashSet<>(bookmarkRepository.findBookmarkedMessageIds(myId));
    }

    @Transactional
    public void delete(Long bookmarkId, Long myId) {
        bookmarkRepository.deleteOwned(bookmarkId, myId);
    }
}
