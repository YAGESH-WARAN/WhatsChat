package com.example.whatsapp.repository;

import com.example.whatsapp.model.Reminder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface ReminderRepository extends JpaRepository<Reminder, Long> {

    /** Open reminders first (soonest first), completed ones at the bottom. */
    @Query("""
            select r from Reminder r
              join fetch r.message m
              join fetch m.sender
              join fetch m.receiver
            where r.user.id = :userId
            order by r.done asc, r.remindAt asc
            """)
    List<Reminder> findAllForUser(@Param("userId") Long userId);

    @Query("select count(r) from Reminder r where r.user.id = :userId and r.done = false and r.remindAt <= :now")
    long countDue(@Param("userId") Long userId, @Param("now") LocalDateTime now);

    @Modifying
    @Query("update Reminder r set r.done = true where r.id = :id and r.user.id = :userId")
    int markDone(@Param("id") Long id, @Param("userId") Long userId);

    @Modifying
    @Query("delete from Reminder r where r.id = :id and r.user.id = :userId")
    int deleteOwned(@Param("id") Long id, @Param("userId") Long userId);

    long countByUserId(Long userId);
}
