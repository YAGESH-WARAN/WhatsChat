package com.example.whatsapp.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** A message converted into a task with an assignee, a deadline and a status. */
@Entity
@Table(name = "tasks")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @ManyToOne(optional = false)
    @JoinColumn(name = "message_id", nullable = false)
    private Message message;

    @ManyToOne(optional = false)
    @JoinColumn(name = "created_by_id", nullable = false)
    private User createdBy;

    @ManyToOne(optional = false)
    @JoinColumn(name = "assignee_id", nullable = false)
    private User assignee;

    @Column(nullable = false)
    private LocalDate deadline;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TaskStatus status = TaskStatus.PENDING;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    protected Task() { }

    public Task(String title, Message message, User createdBy, User assignee, LocalDate deadline) {
        this.title = title;
        this.message = message;
        this.createdBy = createdBy;
        this.assignee = assignee;
        this.deadline = deadline;
    }

    public boolean isOverdue() {
        return status != TaskStatus.COMPLETED && deadline.isBefore(LocalDate.now());
    }

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public Message getMessage() { return message; }
    public User getCreatedBy() { return createdBy; }
    public User getAssignee() { return assignee; }
    public LocalDate getDeadline() { return deadline; }
    public TaskStatus getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
