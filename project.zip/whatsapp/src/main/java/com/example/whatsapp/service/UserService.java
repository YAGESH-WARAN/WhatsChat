package com.example.whatsapp.service;

import com.example.whatsapp.dto.RegisterForm;
import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.security.Principal;
import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public boolean isUsernameTaken(String username) {
        return userRepository.existsByUsernameIgnoreCase(username.trim());
    }

    public boolean isEmailTaken(String email) {
        return userRepository.existsByEmailIgnoreCase(email.trim());
    }

    @Transactional
    public User register(RegisterForm form) {
        String username = form.getUsername().trim();
        String email = form.getEmail().trim().toLowerCase();
        User user = new User(username, email, passwordEncoder.encode(form.getPassword()));
        return userRepository.save(user); // INSERT INTO users ...
    }

    /** The logged-in user, loaded from the Principal that Spring Security provides. */
    public User current(Principal principal) {
        return userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please log in again"));
    }

    public User getById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
    }

    public List<User> otherUsers(Long myId) {
        return userRepository.findByIdNotOrderByUsernameAsc(myId);
    }
}
