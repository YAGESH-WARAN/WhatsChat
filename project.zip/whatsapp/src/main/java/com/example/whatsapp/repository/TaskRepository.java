package com.example.whatsapp.repository;

import com.example.whatsapp.model.Task;
import com.example.whatsapp.model.TaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {

    @Query("""
            select t from Task t
              join fetch t.message m
              join fetch m.sender
              join fetch m.receiver
              join fetch t.createdBy
              join fetch t.assignee
            where t.assignee.id = :userId
            order by t.deadline asc, t.id desc
            """)
    List<Task> findAssignedTo(@Param("userId") Long userId);

    /** Tasks I created for someone else. */
    @Query("""
            select t from Task t
              join fetch t.message m
              join fetch m.sender
              join fetch m.receiver
              join fetch t.createdBy
              join fetch t.assignee
            where t.createdBy.id = :userId and t.assignee.id <> :userId
            order by t.deadline asc, t.id desc
            """)
    List<Task> findAssignedByMe(@Param("userId") Long userId);

    @Query("select count(t) from Task t where t.assignee.id = :userId and t.status <> :done")
    long countOpenAssignedTo(@Param("userId") Long userId, @Param("done") TaskStatus done);

    /** Only the assignee or the creator may change the status. */
    @Modifying
    @Query("""
            update Task t set t.status = :status
            where t.id = :id and (t.assignee.id = :userId or t.createdBy.id = :userId)
            """)
    int updateStatus(@Param("id") Long id, @Param("userId") Long userId, @Param("status") TaskStatus status);

    /** Only the creator may delete a task. */
    @Modifying
    @Query("delete from Task t where t.id = :id and t.createdBy.id = :userId")
    int deleteOwned(@Param("id") Long id, @Param("userId") Long userId);

    long countByCreatedById(Long userId);

    long countByAssigneeId(Long userId);

    long countByAssigneeIdAndStatus(Long userId, TaskStatus status);
}
