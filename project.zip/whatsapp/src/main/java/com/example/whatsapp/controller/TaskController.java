package com.example.whatsapp.controller;

import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.TaskStatus;
import com.example.whatsapp.model.User;
import com.example.whatsapp.service.MessageService;
import com.example.whatsapp.service.TaskService;
import com.example.whatsapp.service.UserService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.time.LocalDate;

@Controller
public class TaskController {

    private final UserService userService;
    private final MessageService messageService;
    private final TaskService taskService;

    public TaskController(UserService userService, MessageService messageService, TaskService taskService) {
        this.userService = userService;
        this.messageService = messageService;
        this.taskService = taskService;
    }

    /** Message -> Task (title + assignee + deadline, status starts as PENDING). */
    @PostMapping("/messages/{messageId}/task")
    public String create(@PathVariable Long messageId,
                         @RequestParam String title,
                         @RequestParam Long assigneeId,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate deadline,
                         Principal principal, RedirectAttributes redirect) {
        User me = userService.current(principal);
        Message message = messageService.getForParticipant(me, messageId);
        try {
            taskService.createFromMessage(me, message, title, assigneeId, deadline);
            redirect.addFlashAttribute("success", "Task created. You will find it under Tasks.");
        } catch (IllegalArgumentException e) {
            redirect.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/chat/" + message.otherPartyId(me.getId());
    }

    @GetMapping("/tasks")
    public String list(Principal principal, Model model) {
        User me = userService.current(principal);
        model.addAttribute("me", me);
        model.addAttribute("assignedToMe", taskService.assignedTo(me.getId()));
        model.addAttribute("assignedByMe", taskService.assignedByMe(me.getId()));
        model.addAttribute("statuses", TaskStatus.values());
        return "tasks";
    }

    @PostMapping("/tasks/{id}/status")
    public String updateStatus(@PathVariable Long id, @RequestParam TaskStatus status, Principal principal) {
        taskService.updateStatus(id, userService.current(principal).getId(), status);
        return "redirect:/tasks";
    }

    @PostMapping("/tasks/{id}/delete")
    public String delete(@PathVariable Long id, Principal principal) {
        taskService.delete(id, userService.current(principal).getId());
        return "redirect:/tasks";
    }
}
