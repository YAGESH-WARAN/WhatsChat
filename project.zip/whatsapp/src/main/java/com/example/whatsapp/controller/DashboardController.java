package com.example.whatsapp.controller;

import com.example.whatsapp.model.User;
import com.example.whatsapp.service.MessageService;
import com.example.whatsapp.service.ReminderService;
import com.example.whatsapp.service.TaskService;
import com.example.whatsapp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;
import java.util.Map;

@Controller
public class DashboardController {

    private final UserService userService;
    private final MessageService messageService;
    private final ReminderService reminderService;
    private final TaskService taskService;

    public DashboardController(UserService userService, MessageService messageService,
                               ReminderService reminderService, TaskService taskService) {
        this.userService = userService;
        this.messageService = messageService;
        this.reminderService = reminderService;
        this.taskService = taskService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Principal principal, Model model) {
        User me = userService.current(principal);
        Map<Long, Long> unread = messageService.unreadBySender(me.getId());

        model.addAttribute("me", me);
        model.addAttribute("users", userService.otherUsers(me.getId()));
        model.addAttribute("unread", unread);
        model.addAttribute("totalUnread", unread.values().stream().mapToLong(Long::longValue).sum());
        model.addAttribute("dueReminders", reminderService.countDue(me.getId()));
        model.addAttribute("openTasks", taskService.countOpenAssignedTo(me.getId()));
        return "dashboard";
    }
}
