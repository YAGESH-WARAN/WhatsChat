package com.example.whatsapp.repository;

import com.example.whatsapp.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {

    /** Full chat history between two users, oldest first. */
    @Query("""
            select m from Message m
              join fetch m.sender
              join fetch m.receiver
            where (m.sender.id = :a and m.receiver.id = :b)
               or (m.sender.id = :b and m.receiver.id = :a)
            order by m.sentAt asc, m.id asc
            """)
    List<Message> findConversation(@Param("a") Long a, @Param("b") Long b);

    /** Marks every unread message that {@code senderId} sent to {@code receiverId} as read. */
    @Modifying(clearAutomatically = true)
    @Query("""
            update Message m set m.isRead = true
            where m.sender.id = :senderId and m.receiver.id = :receiverId and m.isRead = false
            """)
    int markConversationRead(@Param("senderId") Long senderId, @Param("receiverId") Long receiverId);

    /** Rows of [senderId, unreadCount] for the dashboard badges. */
    @Query("""
            select m.sender.id, count(m) from Message m
            where m.receiver.id = :userId and m.isRead = false
            group by m.sender.id
            """)
    List<Object[]> countUnreadGroupedBySender(@Param("userId") Long userId);

    /** Every message the user has sent or received (used for chat insights). */
    @Query("""
            select m from Message m
              join fetch m.sender
              join fetch m.receiver
            where m.sender.id = :userId or m.receiver.id = :userId
            order by m.sentAt asc
            """)
    List<Message> findAllInvolving(@Param("userId") Long userId);
}
