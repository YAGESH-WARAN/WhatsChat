package com.example.whatsapp.controller;

import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.User;
import com.example.whatsapp.service.BookmarkService;
import com.example.whatsapp.service.MessageService;
import com.example.whatsapp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;

@Controller
public class BookmarkController {

    private final UserService userService;
    private final MessageService messageService;
    private final BookmarkService bookmarkService;

    public BookmarkController(UserService userService, MessageService messageService, BookmarkService bookmarkService) {
        this.userService = userService;
        this.messageService = messageService;
        this.bookmarkService = bookmarkService;
    }

    @PostMapping("/messages/{messageId}/bookmark")
    public String toggle(@PathVariable Long messageId, Principal principal, RedirectAttributes redirect) {
        User me = userService.current(principal);
        Message message = messageService.getForParticipant(me, messageId); // 404 if not my chat
        boolean nowBookmarked = bookmarkService.toggle(me, message);
        redirect.addFlashAttribute("success", nowBookmarked ? "Message bookmarked." : "Bookmark removed.");
        return "redirect:/chat/" + message.otherPartyId(me.getId());
    }

    @GetMapping("/bookmarks")
    public String list(Principal principal, Model model) {
        User me = userService.current(principal);
        model.addAttribute("me", me);
        model.addAttribute("bookmarks", bookmarkService.list(me.getId()));
        return "bookmarks";
    }

    @PostMapping("/bookmarks/{id}/delete")
    public String delete(@PathVariable Long id, Principal principal) {
        bookmarkService.delete(id, userService.current(principal).getId());
        return "redirect:/bookmarks";
    }
}
