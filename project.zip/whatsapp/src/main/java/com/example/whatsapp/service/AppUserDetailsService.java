package com.example.whatsapp.service;

import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/** Tells Spring Security how to find a user in MySQL: by username OR by email. */
@Service
public class AppUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public AppUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String input) throws UsernameNotFoundException {
        String id = input == null ? "" : input.trim();
        User user = userRepository.findByUsernameOrEmail(id, id.toLowerCase())
                .orElseThrow(() -> new UsernameNotFoundException("No account found for " + id));

        // The principal name is always the real username, even when the person logged in with an email.
        return org.springframework.security.core.userdetails.User
                .withUsername(user.getUsername())
                .password(user.getPassword())
                .roles("USER")
                .build();
    }
}
