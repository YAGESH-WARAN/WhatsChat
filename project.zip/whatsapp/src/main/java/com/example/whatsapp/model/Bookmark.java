package com.example.whatsapp.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** A message the user starred as important. One bookmark per (user, message). */
@Entity
@Table(name = "bookmarks", uniqueConstraints =
        @UniqueConstraint(name = "uk_bookmark_user_message", columnNames = {"user_id", "message_id"}))
public class Bookmark {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(optional = false)
    @JoinColumn(name = "message_id", nullable = false)
    private Message message;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    protected Bookmark() { }

    public Bookmark(User user, Message message) {
        this.user = user;
        this.message = message;
    }

    public Long getId() { return id; }
    public User getUser() { return user; }
    public Message getMessage() { return message; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
