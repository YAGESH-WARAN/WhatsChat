package com.example.whatsapp.dto;

import java.util.List;

/** Everything shown on the Chat Insights page. */
public record Insights(
        long sent,
        long received,
        long unread,
        long conversations,
        String topContact,          // null when there are no messages yet
        long topContactCount,
        String busiestHourLabel,    // null when there are no messages yet
        double avgWordsPerMessage,
        List<DayActivity> last7Days,
        long bookmarks,
        long reminders,
        long tasksCreated,
        long tasksAssigned,
        long tasksCompleted) {

    /** One bar group of the 7-day chart. Percentages are relative to the busiest day. */
    public record DayActivity(String label, long sent, long received, int sentPct, int receivedPct) { }
}
