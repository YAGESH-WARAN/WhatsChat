package com.example.whatsapp.service;

import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.Task;
import com.example.whatsapp.model.TaskStatus;
import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.TaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    /**
     * Convert a message into a task: "Complete the database module by Friday"
     * becomes a Task with an assignee, a deadline and the status PENDING.
     * The assignee must be one of the two people in that chat.
     */
    @Transactional
    public Task createFromMessage(User me, Message message, String title, Long assigneeId, LocalDate deadline) {
        if (title == null || title.isBlank()) {
            throw new IllegalArgumentException("Task title is required.");
        }
        String cleanTitle = title.trim();
        if (cleanTitle.length() > 200) {
            throw new IllegalArgumentException("Task title is too long (max 200 characters).");
        }
        if (deadline == null) {
            throw new IllegalArgumentException("Please choose a deadline.");
        }
        if (deadline.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Deadline cannot be in the past.");
        }
        if (assigneeId == null || !message.involves(assigneeId)) {
            throw new IllegalArgumentException("The assignee must be one of the two people in this chat.");
        }
        User assignee = message.getSender().getId().equals(assigneeId) ? message.getSender() : message.getReceiver();
        return taskRepository.save(new Task(cleanTitle, message, me, assignee, deadline));
    }

    @Transactional(readOnly = true)
    public List<Task> assignedTo(Long myId) {
        return taskRepository.findAssignedTo(myId);
    }

    @Transactional(readOnly = true)
    public List<Task> assignedByMe(Long myId) {
        return taskRepository.findAssignedByMe(myId);
    }

    @Transactional(readOnly = true)
    public long countOpenAssignedTo(Long myId) {
        return taskRepository.countOpenAssignedTo(myId, TaskStatus.COMPLETED);
    }

    @Transactional
    public void updateStatus(Long taskId, Long myId, TaskStatus status) {
        taskRepository.updateStatus(taskId, myId, status);
    }

    @Transactional
    public void delete(Long taskId, Long myId) {
        taskRepository.deleteOwned(taskId, myId);
    }
}
