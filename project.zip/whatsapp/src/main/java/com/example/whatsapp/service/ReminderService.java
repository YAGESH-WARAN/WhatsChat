package com.example.whatsapp.service;

import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.Reminder;
import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.ReminderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReminderService {

    private final ReminderRepository reminderRepository;

    public ReminderService(ReminderRepository reminderRepository) {
        this.reminderRepository = reminderRepository;
    }

    /** Convert a message into a reminder. The caller has checked the user may access the message. */
    @Transactional
    public Reminder create(User me, Message message, LocalDateTime remindAt, String note) {
        if (remindAt == null) {
            throw new IllegalArgumentException("Please choose a date and time for the reminder.");
        }
        if (remindAt.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Reminder time must be in the future.");
        }
        String cleanNote = (note == null || note.isBlank()) ? null : note.trim();
        if (cleanNote != null && cleanNote.length() > 255) {
            throw new IllegalArgumentException("Note is too long (max 255 characters).");
        }
        return reminderRepository.save(new Reminder(me, message, remindAt, cleanNote));
    }

    @Transactional(readOnly = true)
    public List<Reminder> list(Long myId) {
        return reminderRepository.findAllForUser(myId);
    }

    @Transactional(readOnly = true)
    public long countDue(Long myId) {
        return reminderRepository.countDue(myId, LocalDateTime.now());
    }

    @Transactional
    public void markDone(Long reminderId, Long myId) {
        reminderRepository.markDone(reminderId, myId);
    }

    @Transactional
    public void delete(Long reminderId, Long myId) {
        reminderRepository.deleteOwned(reminderId, myId);
    }
}
