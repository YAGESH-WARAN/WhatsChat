package com.example.whatsapp.controller;

import com.example.whatsapp.model.User;
import com.example.whatsapp.service.BookmarkService;
import com.example.whatsapp.service.MessageService;
import com.example.whatsapp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;

@Controller
public class ChatController {

    private final UserService userService;
    private final MessageService messageService;
    private final BookmarkService bookmarkService;

    public ChatController(UserService userService, MessageService messageService, BookmarkService bookmarkService) {
        this.userService = userService;
        this.messageService = messageService;
        this.bookmarkService = bookmarkService;
    }

    /** Full chat page. Opening it marks the other person's messages as read. */
    @GetMapping("/chat/{userId}")
    public String chat(@PathVariable Long userId, Principal principal, Model model) {
        User me = userService.current(principal);
        if (me.getId().equals(userId)) {
            return "redirect:/dashboard";
        }
        fillModel(model, me, userService.getById(userId));
        return "chat";
    }

    /** Called by chat.js every few seconds. Returns only the message list (a Thymeleaf fragment). */
    @GetMapping("/chat/{userId}/messages")
    public String messages(@PathVariable Long userId, Principal principal, Model model) {
        User me = userService.current(principal);
        fillModel(model, me, userService.getById(userId));
        return "chat :: messageList";
    }

    @PostMapping("/chat/{userId}/send")
    public String send(@PathVariable Long userId, @RequestParam String text,
                       Principal principal, RedirectAttributes redirect) {
        User me = userService.current(principal);
        try {
            messageService.send(me, userId, text);
        } catch (IllegalArgumentException e) {
            redirect.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/chat/" + userId;
    }

    private void fillModel(Model model, User me, User other) {
        model.addAttribute("me", me);
        model.addAttribute("other", other);
        model.addAttribute("messages", messageService.openConversation(me, other.getId()));
        model.addAttribute("bookmarkedIds", bookmarkService.bookmarkedMessageIds(me.getId()));
    }
}
