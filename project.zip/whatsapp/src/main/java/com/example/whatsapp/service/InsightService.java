package com.example.whatsapp.service;

import com.example.whatsapp.dto.Insights;
import com.example.whatsapp.dto.Insights.DayActivity;
import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.TaskStatus;
import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.BookmarkRepository;
import com.example.whatsapp.repository.MessageRepository;
import com.example.whatsapp.repository.ReminderRepository;
import com.example.whatsapp.repository.TaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

@Service
public class InsightService {

    private final MessageRepository messageRepository;
    private final BookmarkRepository bookmarkRepository;
    private final ReminderRepository reminderRepository;
    private final TaskRepository taskRepository;

    public InsightService(MessageRepository messageRepository, BookmarkRepository bookmarkRepository,
                          ReminderRepository reminderRepository, TaskRepository taskRepository) {
        this.messageRepository = messageRepository;
        this.bookmarkRepository = bookmarkRepository;
        this.reminderRepository = reminderRepository;
        this.taskRepository = taskRepository;
    }

    @Transactional(readOnly = true)
    public Insights build(User me) {
        Long id = me.getId();
        return compute(me, messageRepository.findAllInvolving(id), LocalDate.now(),
                bookmarkRepository.countByUserId(id),
                reminderRepository.countByUserId(id),
                taskRepository.countByCreatedById(id),
                taskRepository.countByAssigneeId(id),
                taskRepository.countByAssigneeIdAndStatus(id, TaskStatus.COMPLETED));
    }

    /**
     * Pure calculation (no database) so it is easy to unit-test.
     * Time complexity O(n) for n messages, space O(c + 24 + 7) for c contacts.
     */
    static Insights compute(User me, List<Message> messages, LocalDate today,
                            long bookmarks, long reminders,
                            long tasksCreated, long tasksAssigned, long tasksCompleted) {

        long sent = 0, received = 0, unread = 0, words = 0;
        Map<String, Long> perContact = new TreeMap<>(); // sorted by name -> deterministic tie-break
        long[] perHour = new long[24];
        Map<LocalDate, long[]> perDay = new HashMap<>(); // date -> [sent, received]

        for (Message m : messages) {
            boolean mine = m.getSender().getId().equals(me.getId());
            User other = mine ? m.getReceiver() : m.getSender();
            perContact.merge(other.getUsername(), 1L, Long::sum);
            perHour[m.getSentAt().getHour()]++;
            long[] day = perDay.computeIfAbsent(m.getSentAt().toLocalDate(), d -> new long[2]);
            if (mine) {
                sent++;
                day[0]++;
                words += wordCount(m.getContent());
            } else {
                received++;
                day[1]++;
                if (!m.isRead()) {
                    unread++;
                }
            }
        }

        String topContact = null;
        long topCount = 0;
        for (Map.Entry<String, Long> e : perContact.entrySet()) {
            if (e.getValue() > topCount) {
                topContact = e.getKey();
                topCount = e.getValue();
            }
        }

        int busiestHour = -1;
        long busiestCount = 0;
        for (int h = 0; h < 24; h++) {
            if (perHour[h] > busiestCount) {
                busiestCount = perHour[h];
                busiestHour = h;
            }
        }
        String busiestLabel = busiestHour < 0 ? null : String.format("%02d:00-%02d:00", busiestHour, (busiestHour + 1) % 24);

        // last 7 days (oldest first) with bar heights relative to the busiest value
        long max = 0;
        for (int i = 6; i >= 0; i--) {
            long[] d = perDay.get(today.minusDays(i));
            if (d != null) {
                max = Math.max(max, Math.max(d[0], d[1]));
            }
        }
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("EEE dd", Locale.ENGLISH);
        List<DayActivity> days = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            LocalDate date = today.minusDays(i);
            long[] d = perDay.getOrDefault(date, new long[2]);
            int sentPct = max == 0 ? 0 : (int) (d[0] * 100 / max);
            int recvPct = max == 0 ? 0 : (int) (d[1] * 100 / max);
            days.add(new DayActivity(date.format(fmt), d[0], d[1], sentPct, recvPct));
        }

        double avgWords = sent == 0 ? 0 : (double) words / sent;
        return new Insights(sent, received, unread, perContact.size(), topContact, topCount,
                busiestLabel, avgWords, days, bookmarks, reminders, tasksCreated, tasksAssigned, tasksCompleted);
    }

    private static int wordCount(String text) {
        String t = text == null ? "" : text.trim();
        return t.isEmpty() ? 0 : t.split("\\s+").length;
    }
}
