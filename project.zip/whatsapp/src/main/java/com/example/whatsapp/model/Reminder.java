package com.example.whatsapp.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** "Remind me about this message at this time." */
@Entity
@Table(name = "reminders")
public class Reminder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(optional = false)
    @JoinColumn(name = "message_id", nullable = false)
    private Message message;

    @Column(length = 255)
    private String note;

    @Column(name = "remind_at", nullable = false)
    private LocalDateTime remindAt;

    @Column(nullable = false)
    private boolean done;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    protected Reminder() { }

    public Reminder(User user, Message message, LocalDateTime remindAt, String note) {
        this.user = user;
        this.message = message;
        this.remindAt = remindAt;
        this.note = note;
    }

    /** Not persisted (Hibernate uses field access) - computed when the page is rendered. */
    public boolean isDue() {
        return !done && !remindAt.isAfter(LocalDateTime.now());
    }

    public Long getId() { return id; }
    public User getUser() { return user; }
    public Message getMessage() { return message; }
    public String getNote() { return note; }
    public LocalDateTime getRemindAt() { return remindAt; }
    public boolean isDone() { return done; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
