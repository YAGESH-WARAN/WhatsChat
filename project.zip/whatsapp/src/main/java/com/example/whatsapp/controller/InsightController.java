package com.example.whatsapp.controller;

import com.example.whatsapp.model.User;
import com.example.whatsapp.service.InsightService;
import com.example.whatsapp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;

@Controller
public class InsightController {

    private final UserService userService;
    private final InsightService insightService;

    public InsightController(UserService userService, InsightService insightService) {
        this.userService = userService;
        this.insightService = insightService;
    }

    @GetMapping("/insights")
    public String insights(Principal principal, Model model) {
        User me = userService.current(principal);
        model.addAttribute("me", me);
        model.addAttribute("insights", insightService.build(me));
        return "insights";
    }
}
