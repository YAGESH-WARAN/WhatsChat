package com.example.whatsapp.model;

public enum TaskStatus {
    PENDING("Pending", "bg-secondary"),
    IN_PROGRESS("In Progress", "bg-warning text-dark"),
    COMPLETED("Completed", "bg-success");

    private final String label;
    private final String badge;

    TaskStatus(String label, String badge) {
        this.label = label;
        this.badge = badge;
    }

    public String getLabel() { return label; }

    public String getBadge() { return badge; }
}
