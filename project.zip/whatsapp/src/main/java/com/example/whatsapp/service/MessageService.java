package com.example.whatsapp.service;

import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.MessageRepository;
import com.example.whatsapp.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MessageService {

    static final int MAX_LENGTH = 2000;

    private final MessageRepository messageRepository;
    private final UserRepository userRepository;

    public MessageService(MessageRepository messageRepository, UserRepository userRepository) {
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
    }

    /** Saves a new message. It starts as unread (is_read = false) for the receiver. */
    @Transactional
    public Message send(User sender, Long receiverId, String text) {
        String body = text == null ? "" : text.trim();
        if (body.isEmpty()) {
            throw new IllegalArgumentException("Message cannot be empty.");
        }
        if (body.length() > MAX_LENGTH) {
            throw new IllegalArgumentException("Message is too long (max " + MAX_LENGTH + " characters).");
        }
        if (sender.getId().equals(receiverId)) {
            throw new IllegalArgumentException("You cannot send a message to yourself.");
        }
        User receiver = userRepository.findById(receiverId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        return messageRepository.save(new Message(sender, receiver, body));
    }

    /**
     * Opens a conversation: first marks everything the other person sent me as read,
     * then returns the full history (oldest first).
     */
    @Transactional
    public List<Message> openConversation(User me, Long otherId) {
        messageRepository.markConversationRead(otherId, me.getId());
        return messageRepository.findConversation(me.getId(), otherId);
    }

    /** senderId -> number of unread messages that sender has sent to me. */
    @Transactional(readOnly = true)
    public Map<Long, Long> unreadBySender(Long myId) {
        Map<Long, Long> result = new HashMap<>();
        for (Object[] row : messageRepository.countUnreadGroupedBySender(myId)) {
            result.put((Long) row[0], (Long) row[1]);
        }
        return result;
    }

    /**
     * Loads a message only if the user is a participant of that chat.
     * Anyone else gets a 404, so message ids cannot be probed.
     */
    @Transactional(readOnly = true)
    public Message getForParticipant(User me, Long messageId) {
        Message message = messageRepository.findById(messageId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Message not found"));
        if (!message.involves(me.getId())) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Message not found");
        }
        return message;
    }
}
