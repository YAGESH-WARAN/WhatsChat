package com.example.whatsapp.controller;

import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.User;
import com.example.whatsapp.service.MessageService;
import com.example.whatsapp.service.ReminderService;
import com.example.whatsapp.service.UserService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.time.LocalDateTime;

@Controller
public class ReminderController {

    private final UserService userService;
    private final MessageService messageService;
    private final ReminderService reminderService;

    public ReminderController(UserService userService, MessageService messageService, ReminderService reminderService) {
        this.userService = userService;
        this.messageService = messageService;
        this.reminderService = reminderService;
    }

    /** Message -> Reminder. */
    @PostMapping("/messages/{messageId}/reminder")
    public String create(@PathVariable Long messageId,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime remindAt,
                         @RequestParam(required = false) String note,
                         Principal principal, RedirectAttributes redirect) {
        User me = userService.current(principal);
        Message message = messageService.getForParticipant(me, messageId);
        try {
            reminderService.create(me, message, remindAt, note);
            redirect.addFlashAttribute("success", "Reminder saved. You will find it under Reminders.");
        } catch (IllegalArgumentException e) {
            redirect.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/chat/" + message.otherPartyId(me.getId());
    }

    @GetMapping("/reminders")
    public String list(Principal principal, Model model) {
        User me = userService.current(principal);
        model.addAttribute("me", me);
        model.addAttribute("reminders", reminderService.list(me.getId()));
        return "reminders";
    }

    @PostMapping("/reminders/{id}/done")
    public String done(@PathVariable Long id, Principal principal) {
        reminderService.markDone(id, userService.current(principal).getId());
        return "redirect:/reminders";
    }

    @PostMapping("/reminders/{id}/delete")
    public String delete(@PathVariable Long id, Principal principal) {
        reminderService.delete(id, userService.current(principal).getId());
        return "redirect:/reminders";
    }
}
