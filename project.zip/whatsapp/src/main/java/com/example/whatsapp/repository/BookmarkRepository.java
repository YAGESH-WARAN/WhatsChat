package com.example.whatsapp.repository;

import com.example.whatsapp.model.Bookmark;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface BookmarkRepository extends JpaRepository<Bookmark, Long> {

    @Query("""
            select b from Bookmark b
              join fetch b.message m
              join fetch m.sender
              join fetch m.receiver
            where b.user.id = :userId
            order by b.createdAt desc
            """)
    List<Bookmark> findAllForUser(@Param("userId") Long userId);

    Optional<Bookmark> findByUserIdAndMessageId(Long userId, Long messageId);

    @Query("select b.message.id from Bookmark b where b.user.id = :userId")
    List<Long> findBookmarkedMessageIds(@Param("userId") Long userId);

    /** Deletes only if the bookmark belongs to the user (prevents deleting other people's data). */
    @Modifying
    @Query("delete from Bookmark b where b.id = :id and b.user.id = :userId")
    int deleteOwned(@Param("id") Long id, @Param("userId") Long userId);

    long countByUserId(Long userId);
}
