package com.example.whatsapp.service;

import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.User;
import com.example.whatsapp.repository.MessageRepository;
import com.example.whatsapp.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MessageServiceTest {

    @Mock MessageRepository messageRepository;
    @Mock UserRepository userRepository;
    @InjectMocks MessageService service;

    private User user(long id, String name) {
        User u = new User(name, name + "@mail.com", "hash");
        u.setId(id);
        return u;
    }

    @Test
    void rejectsBlankMessage() {
        assertThrows(IllegalArgumentException.class, () -> service.send(user(1, "yagesh"), 2L, "   "));
    }

    @Test
    void rejectsMessageToSelf() {
        assertThrows(IllegalArgumentException.class, () -> service.send(user(1, "yagesh"), 1L, "hello me"));
    }

    @Test
    void rejectsTooLongMessage() {
        String tooLong = "x".repeat(MessageService.MAX_LENGTH + 1);
        assertThrows(IllegalArgumentException.class, () -> service.send(user(1, "yagesh"), 2L, tooLong));
    }

    @Test
    void savesTrimmedMessageAsUnread() {
        User yagesh = user(1, "yagesh");
        User rahul = user(2, "rahul");
        when(userRepository.findById(2L)).thenReturn(Optional.of(rahul));
        when(messageRepository.save(any(Message.class))).thenAnswer(inv -> inv.getArgument(0));

        Message saved = service.send(yagesh, 2L, "  Hi Rahul!  ");

        assertEquals("Hi Rahul!", saved.getContent());
        assertSame(yagesh, saved.getSender());
        assertSame(rahul, saved.getReceiver());
        assertFalse(saved.isRead());
        assertNotNull(saved.getSentAt());
    }
}
