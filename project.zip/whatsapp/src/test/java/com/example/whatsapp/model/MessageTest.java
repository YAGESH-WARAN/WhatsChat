package com.example.whatsapp.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MessageTest {

    private User user(long id, String name) {
        User u = new User(name, name + "@mail.com", "hash");
        u.setId(id);
        return u;
    }

    @Test
    void newMessageIsUnreadAndTimestamped() {
        Message m = new Message(user(1, "yagesh"), user(2, "rahul"), "Hi Rahul!");
        assertFalse(m.isRead());
        assertNotNull(m.getSentAt());
    }

    @Test
    void involvesOnlyTheTwoParticipants() {
        Message m = new Message(user(1, "yagesh"), user(2, "rahul"), "Hi");
        assertTrue(m.involves(1L));
        assertTrue(m.involves(2L));
        assertFalse(m.involves(3L));
    }

    @Test
    void otherPartyIsTheOppositeUser() {
        Message m = new Message(user(1, "yagesh"), user(2, "rahul"), "Hi");
        assertEquals(2L, m.otherPartyId(1L));
        assertEquals(1L, m.otherPartyId(2L));
    }
}
