package com.example.whatsapp.service;

import com.example.whatsapp.dto.Insights;
import com.example.whatsapp.model.Message;
import com.example.whatsapp.model.User;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InsightServiceTest {

    private User user(long id, String name) {
        User u = new User(name, name + "@mail.com", "hash");
        u.setId(id);
        return u;
    }

    private Message msg(User from, User to, String text, LocalDateTime at, boolean read) {
        Message m = new Message(from, to, text);
        m.setSentAt(at);
        m.setRead(read);
        return m;
    }

    @Test
    void computesCountsTopContactAndBusiestHour() {
        User me = user(1, "yagesh");
        User rahul = user(2, "rahul");
        User priya = user(3, "priya");
        LocalDate today = LocalDate.of(2026, 10, 1);

        List<Message> messages = List.of(
                msg(me, rahul, "hello there", today.atTime(10, 15), true),
                msg(rahul, me, "hi", today.atTime(10, 45), false),
                msg(rahul, me, "how are you", today.atTime(10, 50), false),
                msg(me, priya, "ok", today.atTime(18, 0), true));

        Insights r = InsightService.compute(me, messages, today, 2, 1, 3, 4, 1);

        assertEquals(2, r.sent());
        assertEquals(2, r.received());
        assertEquals(2, r.unread());
        assertEquals(2, r.conversations());
        assertEquals("rahul", r.topContact());
        assertEquals(3, r.topContactCount());
        assertEquals("10:00-11:00", r.busiestHourLabel());
        assertEquals(1.5, r.avgWordsPerMessage(), 0.001); // (2 words + 1 word) / 2 sent

        assertEquals(7, r.last7Days().size());
        Insights.DayActivity lastDay = r.last7Days().get(6);
        assertEquals(2, lastDay.sent());
        assertEquals(2, lastDay.received());
        assertEquals(100, lastDay.sentPct());

        assertEquals(2, r.bookmarks());
        assertEquals(3, r.tasksCreated());
        assertEquals(1, r.tasksCompleted());
    }

    @Test
    void handlesAUserWithNoMessages() {
        User me = user(1, "yagesh");
        Insights r = InsightService.compute(me, List.of(), LocalDate.of(2026, 10, 1), 0, 0, 0, 0, 0);

        assertEquals(0, r.sent());
        assertNull(r.topContact());
        assertNull(r.busiestHourLabel());
        assertEquals(0.0, r.avgWordsPerMessage(), 0.0001);
        assertEquals(7, r.last7Days().size());
    }
}
